﻿define("epi-cms/contentediting/FloatingEditorWrapper", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/Deferred",
    "dojo/topic",
// epi
    "epi/dependency",
    "epi/string",

    "epi/shell/widget/dialog/LightWeight",

    "epi-cms/contentediting/OverlayBasedEditorWrapper"
],

function (
// dojo
    array,
    declare,
    lang,
    aspect,
    Deferred,
    topic,
// epi
    dependency,
    epiString,

    LightWeightDialog,

    OverlayBasedEditorWrapper
) {

    return declare([OverlayBasedEditorWrapper], {
        // summary:
        //      A lightweight dialog used for displaying property editors. This dialog doesn't contain any
        //      buttons, instead it will close when a user clicks on the overlay outside the dialog.
        // tags:
        //      internal

        // formContainerWidgetType: String
        //      Special editor widget type
        formContainerWidgetType: "epi/shell/widget/FormContainer",

        // isOverlayDisabled: Boolean
        //      Override base value to disable overlay when editing.
        isOverlayDisabled: true,

        // isUndoDisabled: Boolean
        //      Override base value to disable undo when editing.
        isUndoDisabled: true,

        // _overlayContainer: [protected] epi.shell.widget.overlay.Container widget
        _overlayContainer: null,

        postCreate: function() {
            this.inherited(arguments);

            var self = this;
            this.own(
                topic.subscribe("/epi/shell/context/request", function(context, callerData) {
                    // Don't stop editing if we are creating a draft.
                    if (!callerData.contextIdSyncChange) {
                        self.tryToStopEditing(false);
                        // Remove the dialog regardless of whether editing stopped correctly
                        // since the context change will occur anyway.
                        self._destroyDialog();
                    }
                }),
                topic.subscribe("/epi/shell/action/changeview", function() {
                    // Remove the editor but don't stop the editing since that will break the
                    // content area's ability to open the create content view via the create link.
                    self._removeEditingFeatures();
                })
            );
        },

        destroy: function () {
            this._removeEditingFeatures();
            this._destroyDialog();
            this.inherited(arguments);
        },

        startEdit: function (params) {
            // summary:
            //    Start editing and show the dialog.
            // tags:
            //    public

            lang.mixin(this.editorParams, params);

            var self = this;

            self._destroyDialog();

            return self._setupDialog().then(function() {
                self.own(
                    aspect.after(self._dialog, "onAfterShow", function() {
                        self._startEdit(params);
                        self._onTryToStopWithInvalidValue();
                    })
                );

                return self._dialog.show();
            });
        },

        _createDialog: function (/*Object*/editor) {
            // summary:
            //      Create dialog
            // editor:
            //      Editor object
            // tags:
            //      protected

            return new LightWeightDialog({
                title: this.propertyDisplayName,
                content: editor,
                duration: 350,
                snapToNode: this.blockDisplayNode,
                positioner: dependency.resolve("epi.shell.layout.PositioningUtility"),
                showButtonContainer: false
            });
        },

        _setBlockDisplayNodeAttr: function(node) {
            this.inherited(arguments);

            var dialog = this._dialog;
            if (dialog) {
                // Work-around permission denied in IE when the document containing the old reference has been unloaded.
                dialog.set("snapToNode", node);
            }
        },

        _setupDialog: function () {
            var _formWidgets = {};

            //Define form's field created event handler.
            var onFieldCreatedHandler = function (fieldName, widget) {
                _formWidgets[fieldName] = widget;
            };

            //Define form's form created event handler.
            var onFormCreatedHandler = lang.hitch(this, function (formContainer) {
                // set parent for each child widget
                for (var fieldName in _formWidgets) {
                    var widget = _formWidgets[fieldName];
                    widget.set("parent", this);
                }

                _formWidgets = null;
            });

            var editorParams = lang.mixin({ intermediateChanges: true }, this.editorParams);

            // Add event only when editor type is FormContainer
            if (this.editorWidgetType === this.formContainerWidgetType) {
                lang.mixin(editorParams, {
                    onFieldCreated: onFieldCreatedHandler,
                    onFormCreated: onFormCreatedHandler,
                    doLayout: false
                });
            }

            var deferred = new Deferred();

            //Change . to /
            var widgetType = epiString.slashName(this.editorWidgetType);

            // Create editor widget
            require([widgetType], lang.hitch(this, function (editorClass) {
                var editor = new editorClass(editorParams);
                this.editorWidget = editor;

                // Create dialog and set content
                var dialog = this._createDialog(editor);

                this._handlers = [
                    this.connect(dialog, "onButtonClose", this._onButtonClose),
                    this.connect(dialog, "onCancel", this._onDialogCancel),
                    this.connect(dialog.doneButtonNode, "onClick", this._onButtonClose),
                    this.connect(editor, "onChange", this._onChange),
                    this.connect(editor, "onKeyPress", "_onEditorKeyPress")
                ];
                this._dialog = dialog;

                // start editor if we created it
                if (this._createdEditor && this.editorWidget.startup) {
                    this.editorWidget.startup();
                }

                deferred.resolve();
            }));

            return deferred.promise;
        },

        _onDialogCancel: function () {
            this.cancel();
        },

        _destroyDialog: function () {
            array.forEach(this._handlers, function (handle) { handle.remove(); });
            this._handlers = null;

            if (this._dialog) {
                this._dialog.destroy();
                this._dialog = null;
            }

            if (this.editorWidget) {
                this.editorWidget.destroy();
                this.editorWidget = null;
            }
        },

        _removeEditingFeatures: function () {
            var dialog = this._dialog;

            if (dialog && dialog.open) {
                dialog.hide();
            }
        },

        _onTryToStopWithInvalidValue: function () {
            // force the editor to show any validation message
            // trigger a blur for the widget and then refocus it
            // this is a workaround to get any validation feedback
            // from widgets that only displays validation message when
            // input fields are blurred
            dijit.focus(this._dialog.titleNode);

            if (this.editorWidget.focus) {
                this.editorWidget.focus();
            }
        },

        _onButtonClose: function () {
            // summary:
            //    Stop editing when the dialog is hidden.
            // tags:
            //    private

            this.tryToStopEditing(false);
        }

    });

});
