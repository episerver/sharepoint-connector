﻿define("epi-cms/dgrid/WithContextMenu", [
    "dojo/_base/declare",
    "epi/shell/DestroyableByKey",
    "epi/shell/widget/ContextMenu"
], function(
    declare,
    DestroyableByKey,
    ContextMenu
) {

    return declare([DestroyableByKey], {
        // summary:
        //      Extension for dgrid that adds a context menu.
        // tags:
        //      public

        // contextMenu: [public] Object
        //      The context menu widget that is bound to the context menu node of each row
        //      in a grid or list.
        contextMenu: null,

        // commandCategory: [public] String
        //      The command category to be used when determining which command should
        //      appear in the context menu.
        commandCategory: "context",

        // _contextMenuClass: [private] String
        //      The CSS class used to identify the context menu node within a dgrid-row.
        _contextMenuClass: "epi-iconContextMenu",

        postCreate: function() {
            // summary:
            //      Called after the list or grid has finished being created but before
            //      startup is called.
            // tags:
            //      protected

            this.inherited(arguments);

            this.contextMenu = this.contextMenu || new ContextMenu({ category: this.commandCategory, popupParent: this });

            this.own(
                this.contextMenu,
                this.on("." + this._contextMenuClass + ":click", this.onContextMenuClick.bind(this))
            );
        },

        startup: function() {
            // summary:
            //      Called automatically after postCreate if the component is already
            //      visible; otherwise, it should be called manually once placed.
            // tags:
            //      protected

            this.inherited(arguments);

            this.contextMenu.startup();
        },

        onContextMenuClick: function(e) {
            // summary:
            //      Opens the context menu at the position the event occured.
            // tags:
            //      protected callback

            this.contextMenu.scheduleOpen(this.domNode, null, {
                x: e.pageX,
                y: e.pageY
            });
        },

        _extendedSelectionHandler: function(e, target) {
            // summary:
            //      Extend the selection handler for "extended" mode, so that clicks on
            //      the context menu of a selected row will not clear the selection.
            // tags:
            //      protected

            var hasContextMenuClass = new RegExp("\\b" + this._contextMenuClass + "\\b");

            // If we are clicking on the context menu and the target row is already
            // selected, then do an early exit in order to avoid deselecting the currently
            // selected rows.
            if (hasContextMenuClass.test(e.target.className) && this.isSelected(target)) {
                return;
            }

            this.inherited(arguments);
        }
    });
});
